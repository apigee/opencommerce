/*
*
* A dummy navigator object - jsrasign expects to be running in a browser and expects 
* these to be in the global namespace
*
*/

var navigator = navigator || {appName : ''};
var window = window || {};